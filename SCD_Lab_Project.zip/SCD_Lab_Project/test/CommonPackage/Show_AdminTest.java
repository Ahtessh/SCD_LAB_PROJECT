/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CommonPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Escanor
 */
public class Show_AdminTest {
  String name="teacher";
    @Test
    public void TestMain()
    {
        
        System.out.println("Recieving ");
        
        
        try {
     Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/scdlabproject", "root", "");

     PreparedStatement st = connection.prepareStatement("Select Username from admin where Username='"+name+"';");

     ResultSet rs = st.executeQuery();
     if (rs.next()) {
         System.out.println(rs.getString("Username"));
         assertEquals(name, rs.getString("Username"));
     } else {
         System.out.println("Error");
     }
     } catch (SQLException sqlException) {
         sqlException.printStackTrace();
 }
}

}
