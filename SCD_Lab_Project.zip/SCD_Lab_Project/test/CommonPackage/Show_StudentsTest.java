/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CommonPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Escanor
 */
public class Show_StudentsTest {
    String S_ID="2";
   
    @Test
    public void TestMain()
    {
        
        System.out.println("Recieving ");
        
        
        try {
     Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/scdlabproject", "root", "");

     PreparedStatement st = connection.prepareStatement("Select stu_roll,stu_name,stu_number from students where stu_roll='"+S_ID+"';");

     ResultSet rs = st.executeQuery();
     if (rs.next()) {
         System.out.println(rs.getString("stu_name"));
         assertEquals(S_ID, rs.getString("stu_roll"));
     } else {
        // System.out.println();
         fail("NO ENTRIES");
     }
     } catch (SQLException sqlException) {
         sqlException.printStackTrace();
 }
}  
}
