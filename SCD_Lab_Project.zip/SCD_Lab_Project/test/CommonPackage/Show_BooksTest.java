/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CommonPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Escanor
 */
public class Show_BooksTest {
     
    String B_name="PEAKY";
    @Test
    public void TestMain()
    {
        
        System.out.println("Recieving ");
        
        
        try {
     Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/scdlabproject", "root", "");

     PreparedStatement st = connection.prepareStatement("Select B_Id,B_Name,B_Self_No from addbooks where B_Name='"+B_name+"';");

     ResultSet rs = st.executeQuery();
     if (rs.next()) {
         System.out.println(rs.getString("B_Id"));
         System.out.println(rs.getString("B_name"));
         System.out.println(rs.getString("B_Self_No"));
         assertEquals(B_name, rs.getString("B_name"));
     } else {
         System.out.println("NO ENTRIES");
     }
     } catch (SQLException sqlException) {
         sqlException.printStackTrace();
 }
}  
    
    
}
