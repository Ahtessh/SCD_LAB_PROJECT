/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Escanor
 */
public class add_adminTest {
    String name="";
    String pass;
   @Before
   
    public void testBefore() {
         name="teacher";
        pass="111";
    } 
    @Test
    public void testMain() {
        System.out.println("Testing Adding Admin ");
        add_admin ad = new add_admin();
        assertEquals(1, ad.Add_Admin(name, pass));
    
    }
      
}
