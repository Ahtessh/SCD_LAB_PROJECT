/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hp
 */
public class AddStudentsTest {
    String S_ID;
    String S_name;
    String S_Number;
   @Before
    public void testBefore() {
         S_ID="2";
     S_name="Uzair";
     S_Number="5";
    }
    @Test
    public void testMain() {
        System.out.println("ADD STUDENT TEST ");
    AddStudents ab = new AddStudents();
   int value =  ab.Add_Student_Function(S_ID, S_name, S_Number);
        assertEquals(1, value);
            
    }
   
}
