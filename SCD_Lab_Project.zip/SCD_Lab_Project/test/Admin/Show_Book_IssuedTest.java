/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Escanor
 */
public class Show_Book_IssuedTest {
    

    @Before
    public void setUp() 
    {
    
    }
    
    @After
    public void tearDown() {
    }

    @Test
   
    public void testMain() throws InterruptedException, AWTException {
        System.out.println("main");
        String[] args = null;
        Show_Book_Issued s = new Show_Book_Issued();
        s.setVisible(true);
        try{
    
    Thread.sleep(2000);

}catch(InterruptedException e)
{System.out.println("e"); }
        
Robot bot = new Robot();
bot.mouseMove(10,10);
bot.mousePress(InputEvent.BUTTON1_MASK);
//add time between press and release or the input event system may 
//not think it is a click
try{
    
    Thread.sleep(250);

}catch(InterruptedException e)
{System.out.println("e"); }
bot.mouseRelease(InputEvent.BUTTON1_MASK);
    
    }
    
    
    
}
