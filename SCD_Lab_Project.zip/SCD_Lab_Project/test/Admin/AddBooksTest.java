/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import static java.lang.System.in;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import sun.applet.Main;

/**
 *
 * @author hp
 */
 public class AddBooksTest{
    String Name;
    String I_D;
    String S_NO;

     @Before
public void Before_Test(){
      Name="HAPPY";
     I_D="56";
     S_NO="2";

    

}
    
@Test
public void Test(){
    
  AddBooks a = new AddBooks();
int i = a.Add_Book_Function(I_D, Name, S_NO);
    assertEquals(1, i);
}
     public static void main(String[] args) {
         
         
         
     }
       
     
}
