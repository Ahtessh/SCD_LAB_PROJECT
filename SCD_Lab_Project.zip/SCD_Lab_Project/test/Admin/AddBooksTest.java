/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hp
 */
public class AddBooksTest {
    String B_id;
   String B_name;
   String B_Shelf_no;
    @Test
    public void testMain() {
        System.out.println("ADD BOOKS TEST");
    AddBooks ab = new AddBooks();
    B_id="22";
     B_name="PEAKY";
     B_Shelf_no="4";
   int value =  ab.Add_Book_Function(B_id, B_name, B_Shelf_no);
        assertEquals(1, value);
    
    }
    
    
    
}
