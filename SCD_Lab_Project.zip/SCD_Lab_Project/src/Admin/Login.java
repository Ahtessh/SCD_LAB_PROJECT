package Admin;


import Admin.AddStudents;
import Admin.Admin_Homepage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/*
AHTESHAM ARSHAD KHAN
JOUN AHMED 
DANIYIAL 
 */
public class Login extends javax.swing.JFrame {
    
    public String Who="";

    public Login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        title = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        password = new javax.swing.JLabel();
        U_name = new javax.swing.JTextField();
        Pass = new javax.swing.JPasswordField();
        back = new javax.swing.JButton();
        bLogin = new javax.swing.JButton();
        bg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        title.setBackground(new java.awt.Color(204, 204, 204));
        title.setFont(new java.awt.Font("Segoe Print", 0, 12)); // NOI18N
        title.setText("   LOGIN");
        title.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        title.setOpaque(true);
        getContentPane().add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 30, 80, 30));

        username.setBackground(new java.awt.Color(204, 204, 204));
        username.setFont(new java.awt.Font("Segoe Print", 0, 12)); // NOI18N
        username.setText("  Username");
        username.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        username.setOpaque(true);
        getContentPane().add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, 100, 30));

        password.setBackground(new java.awt.Color(204, 204, 204));
        password.setFont(new java.awt.Font("Segoe Print", 0, 12)); // NOI18N
        password.setText("  password");
        password.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        password.setOpaque(true);
        getContentPane().add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 100, 30));

        U_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        U_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                U_nameActionPerformed(evt);
            }
        });
        getContentPane().add(U_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 180, 30));

        Pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 180, 30));

        back.setFont(new java.awt.Font("Segoe Print", 0, 12)); // NOI18N
        back.setText("Back");
        back.setBorder(null);
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 210, 90, 30));

        bLogin.setFont(new java.awt.Font("Segoe Print", 0, 12)); // NOI18N
        bLogin.setText("Login");
        bLogin.setBorder(null);
        bLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bLoginActionPerformed(evt);
            }
        });
        getContentPane().add(bLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 210, 90, 30));
        getContentPane().add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 320));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void U_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_U_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_U_nameActionPerformed

    private void bLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bLoginActionPerformed
        // TODO add your handling code here:
       
              try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/scdlabproject", "root", "");
            String username = U_name.getText();
            String password = Pass.getText();
            Statement san = conn.createStatement();
            String query = "select * from admin where Username='" + username + "' and Password='" + password + "'";
            ResultSet rs = san.executeQuery(query);
            if (rs.next()) {
                this.dispose();
                Admin_Homepage AH = new Admin_Homepage();
                AH.setVisible(true);
                
            } else {
                U_name.setText("");
                Pass.setText("");
                JOptionPane.showMessageDialog(rootPane, "Your Username or password is incorrect. Please Enter code in case you forget the Password ");
            }}
        catch (Exception e) {
            System.out.println("Exception occur" + e);
        } 
        

        
        
        
        
       
    }//GEN-LAST:event_bLoginActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        this.dispose();
        AddStudents r = new AddStudents();
        r.setVisible(true);
    }//GEN-LAST:event_backActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField Pass;
    private javax.swing.JTextField U_name;
    private javax.swing.JButton bLogin;
    private javax.swing.JButton back;
    private javax.swing.JLabel bg;
    private javax.swing.JLabel password;
    private javax.swing.JLabel title;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
