package CommonPackage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Escanor
 */
public interface DataBase_Connectivity 
{
    void Table();
    Boolean nullCheck();
    int Add_Student_Function(String st_roll, String st_name, String st_number); // Add students
    int  Add_Book_Function(String B_ID,String B_name,String B_Self_no); // Add Books
    int Add_Admin(String aname,String apass);//Done
    void delete_Book();
    void delete_Student();
    void delete_admin();
    
}
