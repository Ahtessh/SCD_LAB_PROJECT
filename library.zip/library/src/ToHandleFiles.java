
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.FileReader;

public class ToHandleFiles extends ShowBooks
{ 
    public static String ScienceFilePath="C:\\Users\\hp\\Documents\\NetBeansProjects\\Project\\src\\Database\\Science.txt";
    public static String AllFilePath="C:\\Users\\hp\\Documents\\NetBeansProjects\\Project\\src\\Database\\ALL.txt";
    public static String ArtsFilePath="C:\\Users\\hp\\Documents\\NetBeansProjects\\Project\\src\\Database\\Arts.txt";
    public static String StudentsFilePath="C:\\Users\\hp\\Documents\\NetBeansProjects\\Project\\src\\Database\\AllStudents.txt";
    public static String RequestFilePath="C:\\Users\\hp\\Documents\\NetBeansProjects\\Project\\src\\Database\\Request.txt";
    
    public void createScienceFile(String serieal_no,String name,String author,String Cgy) throws IOException
    {
                try {

                FileWriter S = new FileWriter(ScienceFilePath, true);
                FileWriter AB = new FileWriter(AllFilePath, true);
                S.write(serieal_no + " / " + name + " / " + author + " / " + Cgy + " / "+"2nd shelf ");
                S.write(System.getProperty("line.separator"));
                S.close();
               
                AB.write(serieal_no + " / " + name + " / " + author + " / " + Cgy + " / "+"2nd shelf ");
                AB.write(System.getProperty("line.separator"));
                AB.close();
                JOptionPane.showMessageDialog(null, "Successfully added");

            }   catch (IOException ex) {
                System.out.println("ERROR");
            }
    }
    public void createStudentFile(String A,String B,String C,String D) throws IOException
    {
                try {

             
                FileWriter AS = new FileWriter(StudentsFilePath, true);
                AS.write(A + " / " + B + " / " + C + " / " + D );
                AS.write(System.getProperty("line.separator"));
                AS.close();
                JOptionPane.showMessageDialog(null, "Successfully added");

            }   catch (IOException ex) {
                System.out.println("ERROR");
            }
    }
    public void createArtsFile(String serieal_no,String name,String author,String Cgy) throws IOException
    {
    try {
                FileWriter A = new FileWriter(ArtsFilePath, true);
                FileWriter AB = new FileWriter(AllFilePath, true);
                
       
                A.write(serieal_no + " / " + name + " / " + author + " / " + Cgy +" / "+ "3rd shelf ");
                A.write(System.getProperty("line.separator"));
                A.close();
               
                AB.write(serieal_no + " / " + name + " / " + author + " / " + Cgy + " / "+ "3rd shelf ");
                AB.write(System.getProperty("line.separator"));
                AB.close();
                JOptionPane.showMessageDialog(null, "Successfully added");
             
            } catch (IOException ex) {
                System.out.println("ERROR");
            }
    }
    public void createRequestFile(String Name,String Aname) throws IOException
    {
    try {
                FileWriter A = new FileWriter(RequestFilePath, true);
                
       
                A.write(Name + " / " + Aname );
                A.write(System.getProperty("line.separator"));
                A.close();
              
                JOptionPane.showMessageDialog(null, "Successfully added");
             
            } catch (IOException ex) {
                System.out.println("ERROR");
            }
    }
    

   
}
