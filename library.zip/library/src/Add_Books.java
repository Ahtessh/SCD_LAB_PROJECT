
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.System.exit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class Add_Books extends javax.swing.JFrame {
static String name;
static String serieal_no;
static int sno;
static String author;
static String Cgy;
 BinaryTressTools bt = new BinaryTressTools();
 static  BTSopt  bts = new BTSopt();
    public Add_Books() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        S_No_txt = new javax.swing.JTextField();
        Name_txt = new javax.swing.JTextField();
        Author_txt = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        Catagory = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AddBooks");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tempus Sans ITC", 3, 18)); // NOI18N
        jLabel1.setText("Serieal No");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 110, -1));

        jLabel2.setFont(new java.awt.Font("Tempus Sans ITC", 3, 18)); // NOI18N
        jLabel2.setText("Name");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 140, 110, -1));

        jLabel3.setFont(new java.awt.Font("Tempus Sans ITC", 3, 18)); // NOI18N
        jLabel3.setText("Author");
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 110, -1));

        jLabel4.setFont(new java.awt.Font("Tempus Sans ITC", 3, 18)); // NOI18N
        jLabel4.setText("Catogary");
        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 110, -1));

        S_No_txt.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        S_No_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        S_No_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                S_No_txtActionPerformed(evt);
            }
        });
        getContentPane().add(S_No_txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 100, 200, -1));

        Name_txt.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Name_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        getContentPane().add(Name_txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 140, 200, -1));

        Author_txt.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Author_txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        getContentPane().add(Author_txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 180, 200, -1));

        jButton2.setFont(new java.awt.Font("Tempus Sans ITC", 1, 18)); // NOI18N
        jButton2.setText("Add");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 280, 80, 40));

        jButton1.setFont(new java.awt.Font("Tempus Sans ITC", 1, 18)); // NOI18N
        jButton1.setText("Discard");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 280, 100, 40));

        Catagory.setFont(new java.awt.Font("Tempus Sans ITC", 1, 18)); // NOI18N
        Catagory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Science", "Arts" }));
        getContentPane().add(Catagory, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 220, 200, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/03.jpg"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 630, 420));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    
        Cgy = (String) Catagory.getSelectedItem();
        sno= Integer.parseInt(S_No_txt.getText());
    //  BT.getdatafrom(sno);
       name=Name_txt.getText();
       serieal_no=S_No_txt.getText();

   
       author=Author_txt.getText();

  if(chck.x==1)
  {
 JOptionPane.showMessageDialog(rootPane, "Seriel no Already exists");
 chck.x=0;
  setVisible(false);
  new Add_Books().setVisible(true);
  }else{
        if(Cgy=="Science")
        {
            ToHandleFiles h= new ToHandleFiles();
       try {
           h.createScienceFile(serieal_no, name, author, Cgy);
        bts.insertdataFinal(sno,name,author,Cgy);

                 setVisible(false);
                  bts.PrintData_inorder();
                  new Add_Books().setVisible(true);

       } catch (IOException ex) {
           JOptionPane.showMessageDialog(null, "Error added");
       }
        } 
        
        else {
       try {
           ToHandleFiles h= new ToHandleFiles( );
           h.createArtsFile(serieal_no, name, author, Cgy);
              bts.insertdataFinal(sno,name,author,Cgy);
                  setVisible(false);
                  bts.PrintData_inorder();
                  new Add_Books().setVisible(true);

       } catch (IOException ex) {
           JOptionPane.showMessageDialog(null, "Error added");
       }
        }
                
  }
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void S_No_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_S_No_txtActionPerformed
  
       
       
      
    }//GEN-LAST:event_S_No_txtActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     
        setVisible(false);
     HomePage h = new HomePage();
     h.setVisible(true);
     dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

  
    public static void main(String args[]) {
       
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Add_Books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Add_Books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Add_Books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Add_Books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Add_Books().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Author_txt;
    private javax.swing.JComboBox<String> Catagory;
    private javax.swing.JTextField Name_txt;
    private javax.swing.JTextField S_No_txt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
class chck
{
public static int x=0;    
}