
import java.util.Scanner;

public class BinaryTressTools {

   
}
// END OF CALSS
class Node {

    public int Sno;
    public String name;
    public String Aname;
    public String catogary;
    public String Shelf;
    
    public Node left;
    public Node right;

    public Node(int data) {
        Sno = data;
        name=" ";
        Aname="";
        catogary="";
        Shelf="";
        left = null;
        right = null;
    }
    
    public Node(int data,String n,String An,String c) {
        Sno = data;
        name=n;
        Aname=An;
        catogary=c;
        if(catogary == "Science"){
        Shelf="2nd shelf";}
        else
            Shelf="3rd Shelf";
        
        left = null;
        right = null;
    }

    public int GetData() {
        return (Sno );
    }
    public String GetDataS() {
        return ( " " + name +" "+ Aname +" "+ catogary +" "+Shelf);
    }

    public Node GetLeft() {
        return left;
    }

    public Node GetRight() {
        return right;
    }

    public void SetData(int data) {
        Sno = data;
    }

    public void SetLeft(Node L_data) {
        left = L_data;
    }

    public void SetRight(Node R_data) {
        right = R_data;
    }

}
//END OF CALSS NODE

class BTSopt {
chck cc = new chck();
    private int found;
    public Node root;
    public static boolean flag = false;

    public BTSopt() {
        root = null;
        found = 0;

    }


    private void insertFinal(int Sn ,String n,String An,String c ) {
        Node N = new Node(Sn,n,An,c);

        if (root == null)
        {
            root = N;
            System.out.println("Debug Checking Root Update");
        }

        Node PotentialParent, Guide;
        PotentialParent = Guide = root; // during serch modify PotentialParent & Guide not root

        while (Guide != null) // serching  node which will be parent;
        {
            PotentialParent = Guide;
            if (Sn < PotentialParent.GetData()) {
                Guide = PotentialParent.GetLeft();
            } else {
                Guide = PotentialParent.GetRight();
            }

            //PALCING NODE IN LEFT R RIGHT
        }//end of whiloe loooop

        if (Sn < PotentialParent.GetData()) {
            PotentialParent.SetLeft(N);
        } else if (Sn > PotentialParent.GetData()) {
            PotentialParent.SetRight(N);
        }

    }


    public void insertdataFinal(int Sn,String n,String An,String c) {

        if (root == null) {
            insertFinal(Sn,n,An,c);
        }
        else {
            searchNode(root, Sn);
           
            if (flag) {
                System.out.println("Number already exixts");
                cc.x=1;
            } else {
                insertFinal(Sn,n,An,c);
            }
        }
    }

    public void searchNode(Node temp, int value) {
        //Check whether tree is empty  
        flag = false;
        if (root == null) {
            System.out.println("Tree is empty");
        } else {
            //If value is found in the given binary tree then, set the flag to true  
            if (temp.Sno == value) {
                flag = true;
                return;
            }
            //Search in left subtree  
            if (flag == false && temp.left != null) {
                searchNode(temp.left, value);
            }
            //Search in right subtree  
            if (flag == false && temp.right != null) {
                searchNode(temp.right, value);
            }
        }
    }

    public Node Delete_Node(Node root, int key) {
        Node PotentialParent = null;//potential parent
        Node Guide = root;//start root node

        while (Guide != null && Guide.GetData() != key) // serching  node which will be parent;
        {
            PotentialParent = Guide;// update parent ,keep moving
            if (key < PotentialParent.GetData()) {
                Guide = PotentialParent.GetLeft();
            } else {
                Guide = PotentialParent.GetRight();
            }
            if (Guide == null) {
                return root;
            }
        }//end of while
        //CASE 1
        if (Guide.GetLeft() == null && Guide.GetRight() == null)//Mtalab leaf node no child
        {
            if (Guide != root)//special cse of root node 
            {
                if (Guide == PotentialParent.GetLeft()) {
                    PotentialParent.SetLeft(null);
                }
                if (Guide == PotentialParent.GetRight()) {
                    PotentialParent.SetRight(null);
                }
            } else {
                root = null;
            }
        } else if (Guide.GetLeft() == null || Guide.GetRight() == null) {
            Node child = (Guide.GetLeft() != null) ? Guide.GetLeft() : Guide.GetRight();//CHECKING WHICH CHILDS EXISTS

            if (Guide != root) {
                if (PotentialParent.GetRight() == Guide) {
                    PotentialParent.SetRight(child);
                } else {
                    PotentialParent.SetLeft(child);
                }
            } // ager root nde ho or us ka ak hi child ho to ....
            else {
                root = child;
            }

        } //case 3 //2 childs
        else {
            //find in order successor node
            Node successor = minimum(Guide.GetRight());//finding temp node
            //store value
            int val = successor.GetData();
            //recusively delete the successor.
            //successor will have almost one (Right child)

            Delete_Node(root, val);

            Guide.SetData(val);
        }
        return root;
    }

    public Node minimum(Node temp) {
        while (temp.GetLeft() != null) {
            temp = temp.GetLeft();
        }
        return temp;
    }

    public void delete(int key) {
        root = Delete_Node(root, key);
    }

    public void search(int key) {
//    THIS IS SERCH FUNCTION
        Node PotentialParent = null;//potential parent
        Node Guide = root;
        while (Guide != null && Guide.GetData() != key) // serching  node which will be parent;
        {
            PotentialParent = Guide;// keep moving
            if (key < PotentialParent.GetData()) {
                Guide = PotentialParent.GetLeft();
            } else {
                Guide = PotentialParent.GetRight();
            }
        }
        if (Guide.GetData() == key) {
            found = 1;
            System.out.println(" SEARCHESD KEY IS Found: " + Guide.GetData());
        } else {
            found = 0;
            System.out.println(" SEARCHESD KEY IS Not Found: ");
        }
    }

    public void PrintData_inorder() {
        BTS_Inorder(root);
        System.out.println(" ");
    }

    public void PrintData_preorder() {
        BTS_Preorder(root);
        System.out.println(" ");
    }

    public void PrintData_postorder() {
        BTS_Postorder(root);
        System.out.println(" ");
    }

    private void BTS_Inorder(Node p) {
        if (p != null) {
            BTS_Inorder(p.GetLeft());
            System.out.print(p.GetData()+ p.GetDataS() + ",  ");
            BTS_Inorder(p.GetRight());
        }
    }

    private void BTS_Preorder(Node p) {
        if (p != null) {
            System.out.print(p.GetData() + ",  ");
            BTS_Inorder(p.GetLeft());

            BTS_Inorder(p.GetRight());
        }
    }

    private void BTS_Postorder(Node p) {
        if (p != null) {
            BTS_Inorder(p.GetLeft());
            BTS_Inorder(p.GetRight());
            System.out.print(p.GetData() + ",  ");
        }
    }
    public void insertdata(int data){

        if (root == null) {
            insert(data);
        } else {
            searchNode(root, data);
           
            if (flag) {
                System.out.println("Number already exixts");
            } else {
                insert(data);
            }
        }
    }
    private void insert(int data) {
        Node N = new Node(data);

        
        if (root == null) {
            root = N;
            System.out.println("CHANGES");
        }
        
        Node PotentialParent, Guide;
        PotentialParent = Guide = root; // during serch modify PotentialParent & Guide not root

        while (Guide != null) // serching  node which will be parent;
        {
            PotentialParent = Guide;
            if (data < PotentialParent.GetData()) {
                Guide = PotentialParent.GetLeft();
            } else {
                Guide = PotentialParent.GetRight();
            }

            //PALCING NODE IN LEFT R RIGHT
        }//end of whiloe loooop

        if (data < PotentialParent.GetData()) {
            PotentialParent.SetLeft(N);
        } else if (data > PotentialParent.GetData()) {
            PotentialParent.SetRight(N);
        }

    }
    
}
