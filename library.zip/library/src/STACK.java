
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class STACK
{
    private String[] name;
    private String[] Aname;
    private static int Top;
    private static int StackSize;
    public STACK(int temp)
    {
    StackSize=temp;
    name= new String[StackSize];
    Aname= new String[StackSize];
    Top=-1;
    }
    public void push(String temp,String temp2)
    {
        if(Top==StackSize)
        {System.out.println("!!!! STACK IS FULL!!!! ");}
        else
        {
        Top++;
        name[Top]=temp;
        Aname[Top]=temp2;
        System.out.println("Inserted .");
        }
        
        writeinfile(temp,temp2);
    }
    private void writeinfile(String temp,String temp2)
    {
        ToHandleFiles h = new ToHandleFiles();
        try {
            h.createRequestFile(temp, temp2);
        } catch (IOException ex) {
            Logger.getLogger(STACK.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String pop1()
    {
    if(Top<0)
            System.out.println("Stack is empty");
    else
    {
    Top --;
    return(name[Top+1] + Aname[Top+1]);
    }
     return(name[Top+1] + Aname[Top+1]);
       
    }
    
    public void pop()
    {
        if(Top<0)
        {System.out.println("!!!! STACK IS EMPTY!!!! ");}
        else
        {
        System.out.print(name[Top] + " " + Aname[Top]);
        Top--;
        }
    }
      public static boolean IsEmpty()
    {
    if(Top<0)
        return true;
    else 
        return false;
    } 
    public static boolean IsFull()
    {
    if(Top==StackSize)
        return true;
    else 
        return false;
    } 
    public int peek()
    {
        if(Top<0)
        {
        System.out.println("!!!! STACK IS EMPTY!!!! ");
        return -1;
        }
        else
        {  
        return Top;
        }

    }
    public void Display()
    {
        for(int i=Top;i>=0;i--)
        {
        System.out.println("OUTPUT IS : " + name[i] + " " + Aname[Top]);
        }
    }
}
